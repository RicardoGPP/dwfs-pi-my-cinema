<template>
    <!-- TODO -->
    <div/>
</template>

<script>
export default {
    name: 'ComponentName'
}
</script>

<style scoped>
</style>