export default {
    data() {
        return {
            signal: 0
        }
    },
    methods: {
        doSignal() {
            this.signal++;
        }
    }
}